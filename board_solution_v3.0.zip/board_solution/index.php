<?php
/**
 * index.php — 메인 라우터
 * PHP 7.3 / 카페24 호환
 */
define('ROOT', __DIR__);
require_once ROOT . '/config/config.php';

// ── 경로 파싱 ─────────────────────────────────────────────────
// 카페24는 SCRIPT_NAME = /www/index.php 형태이므로
// REQUEST_URI 에서 베이스 디렉토리(/www)를 제거하고 파싱

$uri     = isset($_SERVER['REQUEST_URI'])  ? $_SERVER['REQUEST_URI']  : '/';
$base    = rtrim(dirname(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/index.php'), '/');
$path    = parse_url($uri, PHP_URL_PATH);
$path    = rawurldecode($path);

// 베이스 경로 제거 (/www 등)
if ($base !== '' && $base !== '/' && strpos($path, $base) === 0) {
    $path = substr($path, strlen($base));
}

$path = trim($path, '/');
if ($path === 'index.php') {
    $path = '';
}

$parts = explode('/', $path);
$seg0  = isset($parts[0]) ? $parts[0] : '';
$seg1  = isset($parts[1]) ? $parts[1] : '';
$seg2  = isset($parts[2]) ? $parts[2] : '';

// ── 라우팅 ────────────────────────────────────────────────────
switch ($seg0) {

    case '':
        require ROOT . '/pages/home.php';
        break;

    case 'greeting':
        require ROOT . '/pages/greeting.php';
        break;

    case 'history':
        require ROOT . '/pages/history.php';
        break;

    case 'business':
        require ROOT . '/pages/business.php';
        break;

    case 'auth':
        $authFile = ROOT . '/auth/' . preg_replace('/[^a-z_]/', '', $seg1) . '.php';
        if ($seg1 && file_exists($authFile)) {
            require $authFile;
        } else {
            http_response_code(404);
            require ROOT . '/pages/404.php';
        }
        break;

    case 'board':
        if (empty($seg1)) {
            redirect(SITE_URL);
        }
        $_GET['board_slug'] = $seg1;
        if (!empty($seg2) && ctype_digit($seg2)) {
            $_GET['post_id'] = (int)$seg2;
            require ROOT . '/board/view.php';
        } else {
            require ROOT . '/board/index.php';
        }
        break;

    case 'write':
        $_GET['board_slug'] = $seg1;
        require ROOT . '/board/write.php';
        break;

    case 'edit':
        $_GET['board_slug'] = $seg1;
        $_GET['post_id']    = (int)$seg2;
        require ROOT . '/board/edit.php';
        break;

    case 'sitemap.xml':
        require ROOT . '/sitemap.php';
        break;

    case 'robots.txt':
        header('Content-Type: text/plain');
        echo "User-agent: *\nDisallow: /admin/\nDisallow: /auth/\nSitemap: " . SITE_URL . "/sitemap.xml\n";
        exit;

    default:
        http_response_code(404);
        require ROOT . '/pages/404.php';
        break;
}
