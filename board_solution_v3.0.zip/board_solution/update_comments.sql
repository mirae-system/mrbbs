-- 댓글 수정 기능을 위한 updated_at 컬럼 추가
ALTER TABLE `comments` ADD COLUMN `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP;
